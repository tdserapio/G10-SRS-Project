package q2aa2_cha_cabiao.cajucom.serapio;

import java.util.*;

/**
 *
 * @author CABIAO, CAJUCOM, SERAPIO
 */

public class Player extends Character implements Spawnable{
    private int damage, money;
    
    public Player(String name, float x, float y, float theta, int maxHP, int hp, int damage) {
        super(name, x, y, theta, maxHP, hp);
        this.damage = damage;
        this.money = 0;
    }
    
    
    public int getDamage() {
        return this.damage;
    }
    public int getMoney() {
        return this.money;
    }
    
    public void setMoney(int money) {
        this.money = money;
    }
    
    
    public void spawn(float x, float y) {
        this.x = x;
        this.y = y;
    }
    
    public void talkTo(NPC npc) {
        npc.interact();
    }
    
    public void buyFrom(NPC npc) {
        npc.openShop();
    }
    
    public void purchaseItem(Shop shop) {
        shop.displayItems();
    }
    
    public void buff(String stat, int amount) throws BuffTypeNotFoundException {
        switch(stat) {
            case "coin":
                this.money += amount;
                break;
            case "health":
                this.hp += amount;
                break;
            default:
                throw new BuffTypeNotFoundException();
        }
    }
}
