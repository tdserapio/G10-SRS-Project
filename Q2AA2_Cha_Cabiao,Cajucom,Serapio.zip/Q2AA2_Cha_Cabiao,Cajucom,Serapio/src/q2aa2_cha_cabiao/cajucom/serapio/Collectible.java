package q2aa2_cha_cabiao.cajucom.serapio;

import java.util.*;

/**
 *
 * @author CABIAO, CAJUCOM, SERAPIO
 */

public class Collectible implements Spawnable {

    private float x, y;
    private String type;
    private int value;
    const float RANGE = 20.0;
    const float SENTINEL_VALUE = -10000.0;
    
    public Collectible(float x, float y, String type, int value) {
        this.x = x;
        this.y = y;
        this.type = type;
        this.value = value;
    }
    
    public float getX() {
        return this.x;
    }
    
    public float getY() {
        return this.y;
    }
    
    public String getType() {
        return this.type;
    }
    
    public int getValue() {
        return this.value;
    }
    
    public void collect(Player player) throws PlayerNotFoundException {

        if (this.x - character.x > RANGE && this.x - character.x < -RANGE) {
            throw new PlayerNotFoundException("Player is too far away.");
        } else if (this.y - character.y > RANGE && this.y - character.y < -RANGE){
            throw new PlayerNotFoundException("Player is too far away.");
        } else {
            player.buff(this.type, this.value);
        }

    }

    public void remove() {
        this.x = SENTINEL_VALUE;
    }
    
    public void spawn(float x, float y) {
        this.x = x;
        this.y = y;
    }
}
