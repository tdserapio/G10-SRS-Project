package q2aa2_cha_cabiao.cajucom.serapio;

import java.util.*;

/**
 *
 * @author CABIAO, CAJUCOM, SERAPIO
 */

public class OutOfReachException extends Exception {

    public OutOfReachException() {
        super();
    }
    public OutOfReachException(String message) {
        super(message);
    }

}