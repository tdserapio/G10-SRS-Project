package q2aa2_cha_cabiao.cajucom.serapio;

import java.util.*;

/**
 *
 * @author CABIAO, CAJUCOM, SERAPIO
 */

public class BuffTypeNotFoundException extends Exception {

    public BuffTypeNotFoundException() {
        super();
    }
    public BuffTypeNotFoundException(String message) {
        super(message);
    }

}