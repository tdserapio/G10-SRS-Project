package q2aa2_cha_cabiao.cajucom.serapio;

import java.util.*;

/**
 *
 * @author CABIAO, CAJUCOM, SERAPIO
 */

public class Upgrade {
    private String type;
    private int value;
    
    public Upgrade(String type, int value) {
        this.type = type;
        this.value = value;
    }
    
    public String getType() {
        return this.type;
    }
    public int getValue() {
        return this.value;
    }
    
    public void upgradeUmbrella() {
        System.out.println("Umbrella is upgraded!");
    }
    
    public void remove() {
        this.type = "";
        this.value = 0;
    }
}
