package q2aa2_cha_cabiao.cajucom.serapio;

import java.util.*;

/**
 *
 * @author CABIAO, CAJUCOM, SERAPIO
 */

public class ShopNotFoundException extends Exception {

    public ShopNotFoundException() {
        super();
    }
    public ShopNotFoundException(String message) {
        super(message);
    }

}