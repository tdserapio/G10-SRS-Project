package q2aa2_cha_cabiao.cajucom.serapio;

import java.util.*;

/**
 *
 * @author CABIAO, CAJUCOM, SERAPIO
 */

public class AlreadyDeadException extends Exception {

    public AlreadyDeadException() {
        super();
    }
    public AlreadyDeadException(String message) {
        super(message);
    }

}