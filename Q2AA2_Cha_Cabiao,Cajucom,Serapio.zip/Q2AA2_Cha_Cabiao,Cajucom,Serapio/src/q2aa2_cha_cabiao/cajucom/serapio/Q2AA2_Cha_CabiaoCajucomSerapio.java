package q2aa2_cha_cabiao.cajucom.serapio;

import java.util.*;

/**
 *
 * @author CABIAO, CAJUCOM, SERAPIO
 */

public class Q2AA2_Cha_CabiaoCajucomSerapio {

    public static void main(String[] args) {

        // Use Case #1: player1 interacts with and purchases a “sharper tip” from a traveler
        Player player1 = new Player("Siegfrid", 0.0, 0.0, 0.0, 100, 100, 10);
        
        HashMap<Upgrade, Integer> travelerInventory;
        Shop traveler = new Shop(travelerInventory);
        
        Obstacle obstacle1 = new Obstacle(0.0, 0.0, 10.0, 10.0, 5.0, true, "Wooden");

        Level level2;
        level2.spawnSpawnable(player1, player1.getX(), player1.getY());
        level2.spawnSpawnable(traveler, traveler.getX(), traveler.getY());
        level2.spawnSpawnable(obstacle1, obstacle1.getX(), obstacle1.getY());

        player1.move(29, 5);
        player1.talkTo(traveler);
        player1.buyFrom(traveler);


        // Use Case #2: chaserEnemy attacks player1
        player1 = new Player("Troy", 69.0, 420.0, 0.0, 100, 1, 1);
        Enemy chaserEnemy = new Enemy("Chaser", 60.0, 420.0, 0.0, 100, 10, 100, "Chaser");
       
        Level level3;
        level3.spawnSpawnable(player1, player1.getX(), player1.getY());
        level3.spawnSpawnable(chaserEnemy, chaserEnemy.getX(), chaserEnemy.getY());

        chaserEnemy.moveTowardsPlayer(player1);
        chaserEnemy.attack(player1);

        // Use Case #3: player1 collects coin
        player1 = new Player("Tyrone", 0.0, 0.0, 0.0, 100, 1, 1);
        Collectible coin = new Collectible(0.0, 5.0, "Coin Currency", 1.0);
        Level level4;
        level4.spawnSpawnable(player1, player1.getX(), player1.getY());
        level4.spawnSpawnable(coin, coin.getX(), coin.getY());
        
        player1.move(0, 5.0);
        coin.collect(player1);

    }
    
}
