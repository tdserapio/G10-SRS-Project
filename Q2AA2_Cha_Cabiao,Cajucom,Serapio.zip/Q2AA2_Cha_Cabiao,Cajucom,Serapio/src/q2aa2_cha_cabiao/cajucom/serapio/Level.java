package q2aa2_cha_cabiao.cajucom.serapio;

import java.util.*;

/**
 *
 * @author CABIAO, CAJUCOM, SERAPIO
 */

public class Level {
    private int levelNumber;
    private List<Enemy> enemies;
    private List<Collectible> collectibles;
    private List<Obstacle> obstacles;
    private List<NPC> npcs;
    
    public Level(int levelNumber, List<Enemy> enemies, List<Collectible> Collectibles, List<Obstacle> Obstacles, List<NPC> NPCs) {
        this.levelNumber = levelNumber;
        this.List<Enemy> enemies = List<Enemy> enemies;
        this.List<Collectible> collectibles = List<Collectible> Collectibles;
        this.List<Obstacle> obstacles = List<Obstacle> Obstacles;
        this.List<NPC> npcs = List<NPC> NPCs;
    }
    
    public int getLevelNumber() {
        return this.levelNumber;
    }
    
    public void startLevel() {

        // Spawn enemies
        enemies.forEach(enemy -> {
            enemy.spawn();
        });

        // Spawn collectibles
        collectibles.forEach(collectible -> {
            collectible.spawn();
        });

        // Spawn obstacles
        obstacles.forEach(obstacle -> {
            obstacle.spawn();
        });

        // Spawn NPCs
        npcs.forEach(npc -> {
            npc.spawn();
        });

    }
    
    public void spawnSpawnable(Spawnable i, float x, float y) {
        i.spawn(x, y);
    }
}
