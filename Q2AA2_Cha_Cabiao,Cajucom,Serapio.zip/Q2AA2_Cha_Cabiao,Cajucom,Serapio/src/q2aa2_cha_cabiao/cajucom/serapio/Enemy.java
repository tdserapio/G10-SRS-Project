package q2aa2_cha_cabiao.cajucom.serapio;

import java.util.*;

/**
 *
 * @author CABIAO, CAJUCOM, SERAPIO
 */

public class Enemy extends Character implements Spawnable{
    private String type;
    private int damage;
    private const int STEP_SIZE = 5;
    
    public Enemy(String name, float x, float y, float theta, int maxHP, int hp, int damage, String type) {
        super(name, x, y, theta, maxHP, hp);
        this.damage = damage;
        this.type = type;
    }
        
    public String getType() {
        return this.type;
    }

    public int getDamage() {
        return this.damage;
    }
    
    public void moveTowardsPlayer(Player player) {
        if (player.getX() > this.x) {
            this.x += STEP_SIZE;
        } else {
            this.x -= STEP_SIZE;
        }
        
        if (player.getY() > this.y) {
            this.y += STEP_SIZE;
        } else {
            this.y -= STEP_SIZE;
        }
    }
   
    public void spawn(float x, float y) {
        this.x = x;
        this.y = y;
    }
    
}
