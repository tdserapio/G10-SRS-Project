package q2aa2_cha_cabiao.cajucom.serapio;

import java.util.*;

/**
 *
 * @author CABIAO, CAJUCOM, SERAPIO
 */

public abstract class Character {

    protected String name;
    protected float x, y, theta;
    protected int maxHP, hp;
    const protected int RANGE = 50;
    
    protected Character(String name, float x, float y, float theta, int maxHP, int hp) {
        this.name = name;
        this.x = x;
        this.y = y;
        this.theta = theta;
        this.maxHP = maxHP;
        this.hp = hp;
    }
    
    public String getName() {
        return this.name;
    }

    public float getX() {
        return this.x;
    }

    public float getY() {
        return this.y;
    }

    public float getTheta() {
        return this.theta;
    }

    public int getmaxHP() {
        return this.maxHP;
    }

    public int gethp() {
        return this.hp;
    }
    
    public void move(float x, float y) {
        this.x += x;
        this.y += y;
    }
    
    public void jump() {
        this.y += 10;
    }
    
    public void takeDamage(int damage) throws AlreadyDeadException {
        if (hp > 0) {
            hp -= damage;
        }
        else {
            throw new AlreadyDeadException("Character " + this.name " is dead already!");
        }
    }
    
    public void attack(Character character) throws OutOfReachException {

        if (this.x - character.x > RANGE && this.x - character.x < -RANGE) {
            System.out.println(this.name + "'s attack was not in reach");
            throw new OutOfReachException();
        } else if (this.y - character.y > RANGE && this.y - character.y < -RANGE){
            System.out.println(this.name + "'s attack was not in reach");
            throw new OutOfReachException();
        } else {
            int damage = character.getDamage();
            character.takeDamage(damage);
            return;
        }

    }
    
}
