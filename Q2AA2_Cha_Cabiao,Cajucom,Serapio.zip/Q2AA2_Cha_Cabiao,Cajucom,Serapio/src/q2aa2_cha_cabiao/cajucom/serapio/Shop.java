package q2aa2_cha_cabiao.cajucom.serapio;

import java.util.*;

/**
 *
 * @author CABIAO, CAJUCOM, SERAPIO
 */

public class Shop {
    private HashMap<Upgrade, Integer> inventory;
    
    
    public Shop(HashMap<Upgrade, Integer> inventory) {
        this.inventory = inventory;
    }
    
    public HashMap<Integer, Upgrade> getInventory() {
        return inventory;
    }

    public void displayItems() {
        System.out.println(Arrays.asList(inventory));
    }
    
    public void applyUpgrade(Player player, Upgrade wantedUpgrade) throws BuffTypeNotFoundException {
        if (inventory[wantedUpgrade] > 0) {
            player.buff(chosenUpgrade.getType(), chosenUpgrade.getValue());
        } else {
            throw new BuffTypeNotFoundException();
        }
    }
}
