package q2aa2_cha_cabiao.cajucom.serapio;

import java.util.*;

/**
 *
 * @author CABIAO, CAJUCOM, SERAPIO
 */

public class Obstacle implements Spawnable{
    private float x, y, width, height, speed;
    private boolean isMoving;
    private String material;
    
    
    public Obstacle(float x, float y, float width, float height, float speed, boolean isMoving, String material) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.speed = speed;
        this.isMoving = isMoving;
        this.material = material;
    }
    
    public float getX() {
        return this.x;
    }
    
    public float getY() {
        return this.y;
    }
    
    public float getWidth() {
        return this.width;
    }
    
    public float getHeight() {
        return this.height;
    }
    
    public float getSpeed() {
        return this.speed;
    }

    public boolean getIsMoving() {
        return this.isMoving;
    }

    public String getMaterial() {
        return this.material;
    }
    
    
    public void movePlatform(String direction, float distance) {
        switch(direction) {
            case "up":
                this.y += distance;
                break;
            case "down":
                this.y -= distance;
                break;
            case "right":
                this.x += distance;
                break;
            case "left":
                this.x -= distance;
                break;
            default:
                return;
        }
    }
    
    
    public void changeMaterial(String newMaterial) {
        this.material = newMaterial;
    }
    
    public void spawn(float x, float y) {
        this.x = x;
        this.y = y;
    }
}
