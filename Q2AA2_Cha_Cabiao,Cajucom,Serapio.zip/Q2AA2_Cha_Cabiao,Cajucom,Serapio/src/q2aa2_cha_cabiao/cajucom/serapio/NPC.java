package q2aa2_cha_cabiao.cajucom.serapio;

import java.util.*;

/**
 *
 * @author CABIAO, CAJUCOM, SERAPIO
 */

public class NPC extends Character implements Spawnable{
    private String dialogue;
    private Shop shop;
    
    
    public NPC(String name, float x, float y, float theta, int maxHP, int hp, String dialogue, Shop shop) {
        super(name, x, y, theta, maxHP, hp);
        this.dialogue = dialogue;
        this.shop = shop;
    }
    
    public String getDiaogue() {
        return this.dialogue;
    }
    public Shop getShop() {
        return this.shop;
    }

    public void openShop() {
        if (this.shop) {
            this.shop.displayItems();
        } else {
            return;
        }
    }
    
    public void interact() {
        System.out.println(this.name + ": " + dialogue);
    }
    
    public void spawn(float x, float y) {
        this.x = x;
        this.y = y;
    }
}
