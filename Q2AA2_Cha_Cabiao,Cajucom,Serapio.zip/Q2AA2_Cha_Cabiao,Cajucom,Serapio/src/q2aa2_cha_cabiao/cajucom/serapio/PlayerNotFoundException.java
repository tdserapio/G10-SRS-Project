package q2aa2_cha_cabiao.cajucom.serapio;

import java.util.*;

/**
 *
 * @author CABIAO, CAJUCOM, SERAPIO
 */

public class PlayerNotFoundException extends Exception {

    public PlayerNotFoundException() {
        super();
    }
    public PlayerNotFoundException(String message) {
        super(message);
    }

}